<?php

namespace Spatie\Backtrace\Arguments\ReducedArgument;

class TruncatedReducedArgument extends ReducedArgument
{

}
