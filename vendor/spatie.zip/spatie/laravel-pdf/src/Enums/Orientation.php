<?php

namespace Spatie\LaravelPdf\Enums;

enum Orientation: string
{
    case Portrait = 'Portrait';
    case Landscape = 'Landscape';
}
