<?php

namespace App\Http\Controllers;

use App\Models\Page;
use App\Models\Slider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Str;

class FrontendController extends Controller
{
    public $layout = 'front.layouts.home';

    public function index($slug)
    {
        if (Page::whereSlug($slug)->exists()) {
            $page = Page::whereSlug($slug)->first();
            //$this->layout = View::make('front.layouts.home');

            return response()->view('front.dynamic-pages', ['page' => $page,]);
        } else {
            abort(404);
        }

    }

    public function home(Request $request,)
    {
        if (Page::whereSlug('home')->exists()) {
            $page = Page::whereSlug('home')->first();
            //$this->layout = View::make('front.layouts.home');

            return response()->view('front.dynamic-pages', ['page' => $page,]);
        } else {
            abort(404);
        }
    }

    public function login(Request $request)
    {

        $request->validate([
            'email' => 'string|required|email',
            'password' => 'string|required'
        ]);

        $userCredential = $request->only('email', 'password');


        if (Auth::attempt($userCredential)) {

            //$route = $this->redirectDash();
            return redirect('/dashboard');
        } else {
            return back()->withErrors(['error' => 'Username & Password is incorrect']);
        }

    }

    public function logout(Request $request)
    {
        $request->session()->flush();
        Auth::logout();
        return redirect('/');
    }

}
