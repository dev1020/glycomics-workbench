<?php

namespace App\Providers;

use App\View\Composers\SliderComposer;
use Illuminate\Support\Facades;
use Illuminate\Support\ServiceProvider;
//use Illuminate\View\View;

class ViewServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        Facades\View::composer('front._partials.sliders', SliderComposer::class);
    }
}
